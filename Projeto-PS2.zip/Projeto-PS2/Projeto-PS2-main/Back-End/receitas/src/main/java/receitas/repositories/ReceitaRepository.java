package receitas.repositories;
import java.util.UUID;

//Ana Clara Gierse Raymundo 10428453
//Luana Domingo Branco 10428459
//Victor Luiz de Sá Alves 10426310
import org.springframework.data.repository.CrudRepository;

import receitas.entities.Receita;
/**
 * Extende o CrudRepository para realizar operações CRUD básicas.
 *
 * @author Ana Clara Gierse Raymundo 10428453
 * @author Luana Domingo Branco 10428459
 * @author Victor Luiz de Sá Alves 10426310
 */
public interface ReceitaRepository extends CrudRepository<Receita, UUID> {
}
