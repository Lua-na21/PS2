package receitas;
//Ana Clara Gierse Raymundo 10428453
//Luana Domingo Branco 10428459
//Victor Luiz de Sá Alves 10426310
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Configuração de CORS para a aplicação, permitindo o acesso a recursos da API
 * de origens específicas.
 * 
 * A anotação @EnableWebMvc ativa a configuração web, enquanto @Configuration indica
 * que esta classe contém configurações específicas da aplicação.
 * O método addCorsMappings configura as origens, métodos HTTP permitidos e cabeçalhos
 * permitidos para requisições.
 * 
 * @author Ana Clara Gierse Raymundo 10428453
 * @author Luana Domingo Branco 10428459
 * @author Victor Luiz de Sá Alves 10426310
 */
@EnableWebMvc
@Configuration
public class WebConfigure implements WebMvcConfigurer {

    /**
     * Configura as permissões CORS para a aplicação.
     * Permite requisições de origens específicas, incluindo o frontend em localhost 
     * e em um domínio do GitHub.
     * 
     * @param registry O registro onde as configurações de CORS são feitas.
     */
	@Override
	public void addCorsMappings(CorsRegistry registry) {

		registry.addMapping("/api/**")
		.allowedOrigins("http://localhost:4200", "https://didactic-goggles-pjrqwpjgrqg9f9p9x-4200.app.github.dev")
		.allowedMethods("GET", "POST","OPTIONS", "DELETE")
		.allowedHeaders("*");

		// Add more mappings...
	}
}
