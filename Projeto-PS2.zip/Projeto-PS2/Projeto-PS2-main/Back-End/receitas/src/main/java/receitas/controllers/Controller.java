package receitas.controllers;
//Ana Clara Gierse Raymundo 10428453
//Luana Domingo Branco 10428459
//Victor Luiz de Sá Alves 10426310

import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import receitas.entities.Receita;
import receitas.repositories.ReceitaRepository;
/**
 * Controller responsável pelas operações CRUD das receitas.
 */
@RestController
@RequestMapping("/api/receitas")
public class Controller {
    @Autowired
    private ReceitaRepository repository;

    /**
     * Busca todas as receitas cadastradas no sistema.
     * 
     * @return uma lista de todas as receitas cadastradas.
     */
    @GetMapping()
    public Iterable<Receita> buscarTodos() {
        return repository.findAll();
    }
    
     /**
     * Busca uma receita específica pelo ID.
     * 
     * @param id O identificador único da receita.
     * @return a receita encontrada ou um status 404 (não encontrada).
     */
    @GetMapping("/{id}")
    public ResponseEntity<Receita> getById(@PathVariable UUID id){
        Optional<Receita> receita = repository.findById(id);
        if (receita.isPresent()) {
            return ResponseEntity.ok(receita.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
    /**
     * Cria e salva uma nova receita no banco de dados.
     * 
     * @param novaReceita A receita a ser criada.
     * @return a receita criada com status 201 ou erro caso haja falha.
     */
    @PostMapping()
    public ResponseEntity<Receita> salvarReceita(@RequestBody Receita novaReceita) {
        try {
            novaReceita.setId(UUID.randomUUID());
            Receita savedReceita = repository.save(novaReceita);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedReceita);
        } catch (Exception e) {
            e.printStackTrace();  
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
    /**
     * Deleta uma receita específica com base no ID fornecido.
     * 
     * @param id O identificador único da receita a ser deletada.
     * @return status 204 (no content) se a receita foi deletada, ou 404 (não encontrada) caso o ID não exista.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarReceita(@PathVariable UUID id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.noContent().build(); 
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
    
}
