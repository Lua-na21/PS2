package receitas.entities;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonFormat;

//Ana Clara Gierse Raymundo 10428453
//Luana Domingo Branco 10428459
//Victor Luiz de Sá Alves 10426310
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;

/**
 * Entidade que representa uma receita no banco de dados.
 * Contém informações como nome, descrição, ingredientes, modo de preparo, e URL da imagem.
 * A classe é mapeada para a tabela "receita".
 * 
 * @author Ana Clara Gierse Raymundo 10428453
 * @author Luana Domingo Branco 10428459
 * @author Victor Luiz de Sá Alves 10426310
 */

@Entity
@Table(name = "receita")
public class Receita {
    @Id
    @JsonFormat(shape = JsonFormat.Shape.STRING)  
   private UUID id;    
   private String nome;
    @Lob
    private String descricao;
    @Lob
    private String urlImagem;
    @Lob
    private String ingredientes;
    @Lob
    private String modoPreparo;

      /**
     * Construtor padrão.
     */
    public Receita() {
    }
     /**
     * Construtor com todos os atributos da receita.
     * 
     * @param nome Nome da receita.
     * @param descricao Descrição detalhada da receita.
     * @param urlImagem URL da imagem representando a receita.
     * @param ingredientes Ingredientes necessários para preparar a receita.
     * @param modoPreparo Passos para o preparo da receita.
     */
    public Receita(String nome, String descricao, String urlImagem, String ingredientes, String modoPreparo) {
        this.nome = nome;
        this.descricao = descricao;
        this.urlImagem = urlImagem;
        this.ingredientes = ingredientes;
        this.modoPreparo = modoPreparo;
    }

   /**
     * Retorna o ID da receita.
     * 
     * @return UUID ID da receita.
     */
    public UUID getId() {
        return id;
    }

    /**
     * Retorna o nome da receita.
     * 
     * @return String Nome da receita.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Retorna a descrição da receita.
     * 
     * @return String Descrição da receita.
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * Retorna a URL da imagem da receita.
     * 
     * @return String URL da imagem da receita.
     */
    public String getUrlImagem() {
        return urlImagem;
    }

    /**
     * Retorna os ingredientes da receita.
     * 
     * @return String Ingredientes da receita.
     */
    public String getIngredientes() {
        return ingredientes;
    }

    /**
     * Retorna o modo de preparo da receita.
     * 
     * @return String Modo de preparo da receita.
     */
    public String getModoPreparo() {
        return modoPreparo;
    }

    /**
     * Define o ID da receita.
     * 
     * @param id UUID ID da receita.
     */
    public void setId(UUID id) {
        this.id = id;
    }

    /**
     * Define o nome da receita.
     * 
     * @param nome String Nome da receita.
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Define a descrição da receita.
     * 
     * @param descricao String Descrição da receita.
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    /**
     * Define a URL da imagem da receita.
     * 
     * @param urlImagem String URL da imagem.
     */
    public void setUrlImagem(String urlImagem) {
        this.urlImagem = urlImagem;
    }

    /**
     * Define os ingredientes da receita.
     * 
     * @param ingredientes String Ingredientes da receita.
     */
    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    /**
     * Define o modo de preparo da receita.
     * 
     * @param modoPreparo String Modo de preparo da receita.
     */
    public void setModoPreparo(String modoPreparo) {
        this.modoPreparo = modoPreparo;
    }
}