package receitas.receitas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceitasApplicationTests {

	@Test
	void contextLoads() {
	}

}
