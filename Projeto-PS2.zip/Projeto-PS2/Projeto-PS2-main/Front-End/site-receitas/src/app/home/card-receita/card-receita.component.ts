import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-card-receita',
  standalone: true,
  imports: [],
  templateUrl: './card-receita.component.html',
  styleUrl: './card-receita.component.css'
})
export class CardReceitaComponent implements OnInit {

  constructor(private router: Router) {}
  ngOnInit(): void {
    console.log("Imagem URL emitida: ", this.imagemUrl);
  }

  @Input() titulo: string = '';
  @Input() descricao: string = '';
  @Input() imagemUrl: string = ''; 

  @Input() id!: string;
  @Output() receitaSelecionada = new EventEmitter<string>();

  verReceita() {
    this.router.navigate(['/receita', this.id]);
  }
}
