export interface Receita {
    nome: string;
    descricao: string;
    urlImagem: string;
    ingredientes: string;
    modoPreparo: string;
  }
  