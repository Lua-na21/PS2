npm install -g @angular/cli
 
cd /workspaces/Projeto-PS2/Projeto-PS2-main/Front-End/site-receitas
ou
cd Projeto-PS2-main\Front-End\site-receitas

npm install

ng serve

Ana Clara Gierse Raymundo 10428453
Luana Domingo Branco 10428459
Victor Luiz de Sá Alves 10426310

